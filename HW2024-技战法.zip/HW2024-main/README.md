# HW2024

老板喊我写技战法了
![image](https://github.com/user-attachments/assets/9d47d819-6401-42fc-97cf-9fae6cb36341)
![image](https://github.com/user-attachments/assets/b3f6a3cb-79db-4239-b663-cf139371b8e2)
